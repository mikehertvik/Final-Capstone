package com.techelevator.dao;

import com.techelevator.exception.DaoException;
import com.techelevator.model.Gallery;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class JdbcGalleryDao implements GalleryDao{

    private final JdbcTemplate jdbcTemplate;

    public JdbcGalleryDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    @Override
    public List<Gallery> getGalleryByBandId(int bandId) {
       List<Gallery> galleryList = new ArrayList<>();
        String sql = "SELECT img_url, img_id, band_id FROM gallery WHERE band_id = ?";
        try{
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, bandId);
            while (results.next()){
                Gallery gallery = mapRowToGallery(results);
                galleryList.add(gallery);
            }
        }catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }

        return galleryList;
    }

    @Override
    public Gallery addToGallery(Gallery gallery) {
        Gallery newGallery = null;
        String sql = "INSERT INTO gallery (img_url, band_id) VALUES (?,?) RETURNING img_id";
        try{
            int newImgId = jdbcTemplate.queryForObject(sql, int.class, gallery.getImgUrl(), gallery.getBandId());
            newGallery = getGalleryByImgId(newImgId);
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }
        return newGallery;
    }

    @Override
    public Gallery getGalleryByImgId(int imgId) {
        Gallery gallery = null;
        String sql = "SELECT img_id, img_url, band_id FROM gallery WHERE img_id = ?";
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, imgId);
            if (results.next()){
                gallery = mapRowToGallery(results);
            }
        }catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }
        return gallery;
    }

    private Gallery mapRowToGallery(SqlRowSet rs){
        Gallery gallery = new Gallery();
        gallery.setBandId(rs.getInt("band_id"));
        gallery.setImgId(rs.getInt("img_id"));
        gallery.setImgUrl(rs.getString("img_url"));
        return gallery;
    }

}
