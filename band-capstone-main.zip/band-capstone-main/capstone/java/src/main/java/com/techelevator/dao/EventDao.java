package com.techelevator.dao;

import com.techelevator.model.Event;

import java.util.List;

public interface EventDao {
    List<Event> getEventsByBand(int bandId);
    Event getEventById(int eventId);

    Event createEvent(int bandId, Event event);

    Event updateEvent(int bandId, Event event);

    void deleteEvent(int eventId);

}
