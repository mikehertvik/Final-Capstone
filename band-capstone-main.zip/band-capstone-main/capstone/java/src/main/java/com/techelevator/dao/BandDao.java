package com.techelevator.dao;

import com.techelevator.model.Band;
import com.techelevator.model.User;

import java.util.List;

public interface BandDao {
    List<Band> getRandomBands(int count);

    List<Band> getBandsByName(String bandName, int userId);
    List<Band> getAllBands(int userId);
    Band getBandByName(String name, int userId);


    Band getBandById(int bandId, int userId);

    Band createBand(Band band, int userId);

    Band updateBand(Band band);


}


