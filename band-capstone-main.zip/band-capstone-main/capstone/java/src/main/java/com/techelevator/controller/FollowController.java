package com.techelevator.controller;


import com.techelevator.dao.FollowDao;
import com.techelevator.dao.UserDao;
import com.techelevator.model.Band;
import com.techelevator.model.Follow;
import com.techelevator.model.User;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@PreAuthorize("isAuthenticated()")
@RestController
@CrossOrigin
public class FollowController {

    private final FollowDao followDao;
    private final UserDao userDao;


    public FollowController(FollowDao followDao, UserDao userDao) {
        this.followDao = followDao;
        this.userDao = userDao;
    }

    @GetMapping(path="/following/{bandId}")
    public  boolean isFollowing(Principal principal, @PathVariable(required = true) int  bandId) {
        int userId = userDao.getUserByUsername(principal.getName()).getId();
        return followDao.isFollowing(userId, bandId);
    }

    @PutMapping(path="/bands/{bandId}")
    public Follow followBand(@PathVariable(required = true) int bandId, Principal principal) {
        int userId = userDao.getUserByUsername(principal.getName()).getId();
        return followDao.followBand(userId, bandId);
    }
    @GetMapping(path="/followers/count/{bandId}")
    public int getFollowerCount(@PathVariable int bandId) {
        return followDao.getFollowerCountByBandId(bandId);
    }

    @DeleteMapping(path="/following/{bandId}")
    public boolean unfollowBand(@PathVariable(required = true) int bandId, Principal principal) {
        int userId = userDao.getUserByUsername(principal.getName()).getId();
        return followDao.unfollowBand(userId, bandId);
    }
}

