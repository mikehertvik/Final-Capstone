package com.techelevator.model;

public class BandDto {
    private int bandId;
    private String name;
    private int genreId;
    private int creator;
    private String bio;
    private String profileImg;
    private String bannerImg;
//    private int followerCount;


    public int getBandId() {
        return bandId;
    }

    public void setBandId(int bandId) {
        this.bandId = bandId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGenreId() {
        return genreId;
    }

    public void setGenreId(int genreId) {
        this.genreId = genreId;
    }

    public int getCreator() {
        return creator;
    }

    public void setCreator(int creator) {
        this.creator = creator;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getProfileImg() {
        return profileImg;
    }

    public void setProfileImg(String profileImg) {
        this.profileImg = profileImg;
    }

    public String getBannerImg() {
        return bannerImg;
    }

    public void setBannerImg(String bannerImg) {
        this.bannerImg = bannerImg;
    }
//    public int getFollowerCount() {
//        return followerCount;
//    }
//
//    public void setFollowerCount(int followerCount) {
//        this.followerCount = followerCount;
//    }

    public String toString(Band band) {
        return "BandDto{" +
                "bandId='" + band.getBandId() + '\'' +
                ", name='" + band.getName() + '\'' +
                ", genreId='" + band.getGenreId() + '\'' +
                ", creator='" + band.getCreator() + '\'' +
                ", bio='" + band.getBio() + '\'' +
                ", profileImg='" + band.getProfileImg() + '\'' +
                ", bannerImg='" + band.getBannerImg() + '\'' +
                ", userFollowing='" + band.getUserFollowing() + '\'' +
                '}';
    }

}
