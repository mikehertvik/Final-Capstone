package com.techelevator.dao;

import com.techelevator.model.Gallery;

import java.util.List;

public interface GalleryDao {


    List<Gallery> getGalleryByBandId(int bandId);

    Gallery addToGallery(Gallery gallery);

    Gallery getGalleryByImgId(int imgId);

}
