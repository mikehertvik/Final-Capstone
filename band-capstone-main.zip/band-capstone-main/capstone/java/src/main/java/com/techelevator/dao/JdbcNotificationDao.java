package com.techelevator.dao;

import com.techelevator.exception.DaoException;
import com.techelevator.model.Notification;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;

@Component
public class JdbcNotificationDao implements NotificationDao{

    private JdbcTemplate jdbcTemplate;

    public JdbcNotificationDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    public List<Notification> getAllNotifications(int userId) {
        List<Notification> notifications = new ArrayList<>();
        String sql = "SELECT n.notif_id\n" +
                ", n.notif_message\n" +
                ", n.date_sent\n" +
                ", n.band_id\n" +
                ", n.notif_subject\n" +
                ", u.last_inbox_check\n" +
                ", b.name \n" +
                "AS band_name\n" +
                "FROM notifications n\n" +
                "JOIN following f ON n.band_id = f.band_id\n" +
                "JOIN users u ON f.user_id = u.user_id\n" +
                "JOIN band b ON n.band_id = b.band_id\n" +
                "WHERE u.user_id = ?\n" +
                "ORDER BY date_sent DESC;";
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, userId);
            while(results.next()) {
                notifications.add(mapRowToNotification(results));
            }
        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }

        return notifications;
    }

    @Override
    public Notification getNotificationById(int notificationId) {
        Notification notification = null;
        String sql = "SELECT n.notif_id\n" +
                ", n.notif_message\n" +
                ", n.date_sent\n" +
                ", n.band_id\n" +
                ", n.notif_subject\n" +
                ", u.last_inbox_check\n" +
                ", b.name \n" +
                "AS band_name\n" +
                "FROM notifications n\n" +
                "JOIN following f ON n.band_id = f.band_id\n" +
                "JOIN users u ON f.user_id = u.user_id\n" +
                "JOIN band b ON n.band_id = b.band_id\n" +
                "WHERE n.notif_id = ?";
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, notificationId);
            if (results.next()) {
                notification = mapRowToNotification(results);
            }
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }
        return notification;
    }

    public Notification createNotification(Notification notification){
        Notification newNotification = null;
        String sql = "INSERT INTO notifications (notif_message, notif_subject, band_id, date_sent)" +
                "VALUES (?, ?, ?, ?) RETURNING notif_id";
        try{
            int newNotificationId = jdbcTemplate.queryForObject(sql, int.class, notification.getNotifMessage(), notification.getNotifSubject(), notification.getBandId(), notification.getDateSent());
            newNotification = getNotificationById(newNotificationId);
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }

        return newNotification;
    }

    public Notification mapRowToNotification(SqlRowSet rs) {
        Notification notification = new Notification();
        notification.setNotifId(rs.getInt("notif_id"));
        notification.setNotifMessage(rs.getString("notif_message"));
        notification.setNotifSubject(rs.getString("notif_subject"));
        notification.setBandId(rs.getInt("band_id"));
        notification.setBandName(rs.getString("band_name"));
        notification.setDateSent(rs.getTimestamp("date_sent").toLocalDateTime());
        return notification;
    }
}
