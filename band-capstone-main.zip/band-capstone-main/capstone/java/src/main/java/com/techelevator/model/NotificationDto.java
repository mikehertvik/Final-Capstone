package com.techelevator.model;

import java.time.LocalDateTime;

public class NotificationDto {
    private int notifId;
    private String message;
    private LocalDateTime dateSent;
    private int bandId;
    private String notifSubject;

    public int getNotifId() {
        return notifId;
    }

    public void setNotifId(int notifId) {
        this.notifId = notifId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getDateSent() {
        return dateSent;
    }

    public void setDateSent(LocalDateTime dateSent) {
        this.dateSent = dateSent;
    }

    public int getBandId() {
        return bandId;
    }

    public void setBandId(int bandId) {
        this.bandId = bandId;
    }

    public String getNotifSubject() {
        return notifSubject;
    }

    public void setNotifSubject(String notifSubject) {
        this.notifSubject = notifSubject;
    }

    public String toString(Notification notification) {
        return "NotificationDto{" +
                "notifId='" + notification.getNotifId() + '\'' +
                "message='" + notification.getNotifMessage() + '\'' +
                "notifSubject='" + notification.getNotifSubject() + '\'' +
                "bandId='" + notification.getBandId() + '\'' +
                "dateSent='" + notification.getDateSent() + '\'' +
                "bandName='" + notification.getBandName() + '\'' +
                '}';
    }
}

