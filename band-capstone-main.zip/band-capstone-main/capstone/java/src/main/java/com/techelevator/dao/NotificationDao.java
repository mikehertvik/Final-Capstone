package com.techelevator.dao;

import com.techelevator.model.Notification;
import org.springframework.data.relational.core.sql.Not;

import java.util.List;

public interface NotificationDao {
    List<Notification> getAllNotifications(int userId);

    Notification createNotification(Notification notification);

    Notification getNotificationById(int notificationId);

}
