package com.techelevator.controller;


import com.techelevator.dao.EventDao;
import com.techelevator.model.Event;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("isAuthenticated()")
@CrossOrigin
public class EventController {

    private final EventDao eventDao;

    public EventController(EventDao eventDao) {
        this.eventDao = eventDao;
    }

    @GetMapping("/bands/{bandId}/events")
    public List<Event> getEventsByBand(@PathVariable int bandId) {
        return eventDao.getEventsByBand(bandId);
    }

    @GetMapping("/bands/{bandId}/events/{eventId}")
    public Event getEventById(@PathVariable int eventId) {
        return eventDao.getEventById(eventId);
    }

    @PostMapping("/bands/{bandId}/events/create")
    public Event createEvent(@PathVariable int bandId, @RequestBody Event event) {
        return eventDao.createEvent(bandId, event);
    }

    @PutMapping("/bands/{bandId}/events/{eventId}/update")
    public Event updateEvent(@PathVariable int bandId,@PathVariable int eventId,  @RequestBody Event event) {
        event.setEventId(eventId);
        return eventDao.updateEvent(bandId, event);
    }

    @DeleteMapping("/bands/{bandId}/events/{eventId}/delete")
    public void deleteEvent(@PathVariable int eventId) {
        eventDao.deleteEvent(eventId);
    }
}
