package com.techelevator.dao;

import com.techelevator.exception.DaoException;
import com.techelevator.model.Event;
import com.techelevator.model.Follow;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class JdbcEventDao implements EventDao {
    private final JdbcTemplate jdbcTemplate;

    public JdbcEventDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    @Override
    public List<Event> getEventsByBand(int bandId) {
        String sql = "SELECT event_name\n" +
                ", event_id\n" +
                ", event_venue\n" +
                ", event_address\n" +
                ", event_date_time\n" +
                ", band_id\n" +
                "FROM events\n" +
                "WHERE band_id = ?\n" +
                "ORDER BY event_date_time";
        List<Event> events = new ArrayList<>();
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, bandId);
            while (results.next()) {
                Event event = mapRowToEvent(results);
                events.add(event);
            }
        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }

        return events;
    }

    @Override
    public Event createEvent(int bandId, Event event) {
        String sql = "INSERT INTO events (event_name, event_venue, event_address, event_date_time, band_id)\n" +
                "VALUES ( ? , ? , ? , ? , ? ) RETURNING event_id";
        int newEventId = 0;
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql,
                    event.getEventName(),
                    event.getEventVenue(),
                    event.getEventAddress(),
                    event.getEventDateTime(),
                    bandId);
            if (results.next()) {
                newEventId = results.getInt("event_id");
                Event newEvent = getEventById(newEventId);
                return newEvent;
            } else {
                return null;
            }

        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch(DataIntegrityViolationException e) {
            throw new DaoException("Data Integrity Violation", e);
        }
    }

    @Override
    public Event updateEvent(int bandId, Event event) {
        String sql = "UPDATE events\n" +
                "SET event_name = ?, event_venue = ?, event_address = ?, event_date_time = ?\n" +
                "WHERE event_id = ? AND band_id = ? ";

        try {
            int rowsAffected = jdbcTemplate.update(sql,
                    event.getEventName(),
                    event.getEventVenue(),
                    event.getEventAddress(),
                    event.getEventDateTime(),
                    event.getEventId(),
                    bandId);
            if(rowsAffected == 0) {
                throw new DaoException("No event found to update or user is not the creator.");
            }
            int eventId = event.getEventId();
            Event newEvent = getEventById(eventId);
            return newEvent;

        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch(DataIntegrityViolationException e) {
            throw new DaoException("Data Integrity Violation", e);
        }
    }

    @Override
    public void deleteEvent(int eventId) {
        String sql = "DELETE FROM events\n" +
                "WHERE event_id = ?";
        try {
            int rowsDeleted = jdbcTemplate.update(sql, eventId);
        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }
    }

    @Override
    public Event getEventById(int eventId) {
        String sql = "SELECT event_id, event_name, event_venue, event_address, event_date_time, band_id\n" +
                "FROM events\n" +
                "WHERE event_id = ?";
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, eventId);
            if(results.next()) {
                Event event = mapRowToEvent(results);
                return event;
            }
            return null;

        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }

    }

    public Event mapRowToEvent(SqlRowSet rs) {
        Event event = new Event();
        event.setEventId(rs.getInt("event_id"));
        event.setBandId(rs.getInt("band_id"));
        event.setEventName(rs.getString("event_name"));
        event.setEventAddress(rs.getString("event_address"));
        event.setEventVenue(rs.getString("event_venue"));
        event.setEventDateTime(rs.getTimestamp("event_date_time").toLocalDateTime());
        return event;
    }
}
