package com.techelevator.controller;

import com.techelevator.dao.GalleryDao;
import com.techelevator.dao.UserDao;
import com.techelevator.model.Band;
import com.techelevator.model.Gallery;
import com.techelevator.model.User;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
@PreAuthorize("isAuthenticated()")
@RestController
@CrossOrigin
public class GalleryController {

    GalleryDao galleryDao;

    UserDao userDao;


    public GalleryController(GalleryDao galleryDao, UserDao userDao) {
        this.galleryDao = galleryDao;
        this.userDao = userDao;
    }

    @GetMapping("/bands/{bandId}/gallery")
    public List<Gallery> getGalleryByBandId(@PathVariable(required = true) int bandId) {
//        int userId = userDao.getUserByUsername(principal.getName()).getId();
        return galleryDao.getGalleryByBandId(bandId);
    }

    @PostMapping("/bands/{bandId}/gallery")
    public Gallery addToGallery(@PathVariable(required = true) int bandId, @RequestBody Gallery gallery){
        gallery.setBandId(bandId);
        return galleryDao.addToGallery(gallery);
    }


}

