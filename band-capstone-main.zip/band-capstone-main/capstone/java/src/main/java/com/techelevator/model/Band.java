package com.techelevator.model;

import java.util.ArrayList;
import java.util.List;

public class Band {
    private int bandId;
    private String name;
    private int genreId;

    private String genreName;
    private int creator;
    private String bio;
    private String profileImg;
    private String bannerImg;
    private boolean userFollowing;
    public Band(int bandId, String name, int genreId, int creator,
                String bio, String profileImg, String bannerImg, boolean userFollowing) {
        this.bandId = bandId;
        this.name = name;
        this.genreId = genreId;
        this.creator = creator;
        this.bio = bio;
        this.profileImg = profileImg;
        this.bannerImg = bannerImg;
        this.userFollowing = userFollowing;
//        this.followerCount = followerCount;
    }
    private List<String> genres = new ArrayList<>();
    public Band(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGenreId() {
        return genreId;
    }

    public void setGenreId(int genreId) {
        this.genreId = genreId;
    }

    public int getCreator() {
        return creator;
    }

    public void setCreator(int creator) {
        this.creator = creator;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getProfileImg() {
        return profileImg;
    }

    public void setProfileImg(String profileImg) {
        this.profileImg = profileImg;
    }

    public String getBannerImg() {
        return bannerImg;
    }

    public void setBannerImg(String bannerImg) {
        this.bannerImg = bannerImg;
    }
    public int getBandId() {
        return bandId;
    }

    public void setBandId(int bandId) {
        this.bandId = bandId;
    }

    public String getGenreName() {
        return genreName;
    }

    public void setGenreName(String genreName) {
        this.genreName = genreName;
    }

    public List<String> getGenres() {
        return genres;
    }

    public void setGenres(List<String> genres) {
        this.genres = genres;
    }

    public boolean getUserFollowing() {
        return userFollowing;
    }

    public void setUserFollowing(boolean userFollowing) {
        this.userFollowing = userFollowing;
    }

//    public int getFollowerCount() {
//        return followerCount;
//    }
//
//    public void setFollowerCount(int followerCount) {
//        this.followerCount = followerCount;
//    }
private List<Integer> genreIds;

    public List<Integer> getGenreIds() {
        return genreIds;
    }

    public void setGenreIds(List<Integer> genreIds) {
        this.genreIds = genreIds;
    }

}
