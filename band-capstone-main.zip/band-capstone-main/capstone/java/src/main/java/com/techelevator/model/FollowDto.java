package com.techelevator.model;

public class FollowDto {

    private int userId;
    private int bandId;

    public int getUser_id() {
        return userId;
    }

    public void setUser_id(int userId) {
        this.userId = userId;
    }

    public int getBand_id() {
        return bandId;
    }

    public void setBand_id(int bandId) {
        this.bandId = bandId;
    }

    public String toString(Follow follow) {
        return "FollowDto{" +
                "bandId='" + follow.getBand_id() + '\'' +
                "userId='" + follow.getUser_id() + '\'' +
                '}';
    }

}
