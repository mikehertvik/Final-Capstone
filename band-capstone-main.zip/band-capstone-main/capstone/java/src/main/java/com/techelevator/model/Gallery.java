package com.techelevator.model;

public class Gallery {

    public int getImgId() {
        return imgId;
    }

    public void setImgId(int imgId) {
        this.imgId = imgId;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public int getBandId() {
        return bandId;
    }

    public void setBandId(int bandId) {
        this.bandId = bandId;
    }

    private int imgId;
    private String imgUrl;

    private int bandId;

    public Gallery(int imgId, String imgUrl, int bandId) {
        this.imgId = imgId;
        this.imgUrl = imgUrl;
        this.bandId = bandId;
    }

    public Gallery(){

    }
}
