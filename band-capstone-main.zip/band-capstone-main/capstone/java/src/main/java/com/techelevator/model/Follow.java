package com.techelevator.model;

public class Follow {

    private int userId;
    private int bandId;

    public Follow(int bandId, int userId) {
        this.bandId = bandId;
        this.userId = userId;

    }

    public Follow() {

    }

    public int getUser_id() {
        return userId;
    }

    public void setUser_id(int userId) {
        this.userId = userId;
    }

    public int getBand_id() {
        return bandId;
    }

    public void setBand_id(int bandId) {
        this.bandId = bandId;
    }

}
