package com.techelevator.dao;

import com.techelevator.model.Band;
import com.techelevator.model.Follow;
import com.techelevator.model.User;

import java.util.List;

public interface FollowDao {

    boolean isFollowing(int userId, int bandId);
    Follow followBand(int userId, int bandId);
    boolean unfollowBand(int userId, int bandId);

    int getFollowerCountByBandId(int bandId);


}
