package com.techelevator.dao;

import com.techelevator.exception.DaoException;
import com.techelevator.model.Band;
import com.techelevator.model.Follow;
import com.techelevator.model.User;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class JdbcFollowDao implements FollowDao{

    private final JdbcTemplate jdbcTemplate;

    public JdbcFollowDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public boolean isFollowing(int userId, int bandId) {
        String sql = "SELECT f.user_id, f.band_id " +
                "FROM following f " +
                "WHERE f.user_id = ? AND f.band_id = ?";
        boolean following = false;

        try{
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, userId, bandId);
            if (results.next()) {
                following = true;
            }
        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }

        return following;
    }

    @Override
    public Follow followBand(int userId, int bandId) {
        String sql = "INSERT INTO following (user_id, band_id)\n" +
                "VALUES (?, ?) RETURNING user_id, band_id;";
        Follow follow = null;
        try {
             SqlRowSet results = jdbcTemplate.queryForRowSet(sql, userId, bandId);
            if (results.next()) {
                follow = mapRowToFollow(results);
            }
        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch(DataIntegrityViolationException e) {
            throw new DaoException("Data Integrity Violation", e);
        }
        return follow;
    }

    @Override
    public boolean unfollowBand(int userId, int bandId) {
        String sql = "DELETE FROM following\n" +
                "WHERE user_id = ? AND band_id = ?";
        int rowsDeleted = 0;
        try {
            rowsDeleted = jdbcTemplate.update(sql, userId, bandId);
        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }

        if(rowsDeleted == 0) {
            return false;
        } else {
            return true;
        }
    }


    private Follow mapRowToFollow(SqlRowSet rs) {
        Follow follow = new Follow();
        follow.setBand_id(rs.getInt("band_id"));
        follow.setUser_id(rs.getInt("user_id"));
        return follow;
    }
//changed follow to following
    @Override
    public int getFollowerCountByBandId(int bandId) {
        String sql = "SELECT COUNT(*) FROM following WHERE band_id = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, bandId);
        return (count != null) ? count : 0;
    }


}
