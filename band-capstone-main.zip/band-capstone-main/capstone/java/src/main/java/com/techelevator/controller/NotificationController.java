package com.techelevator.controller;


import com.techelevator.dao.BandDao;
import com.techelevator.dao.NotificationDao;
import com.techelevator.dao.UserDao;
import com.techelevator.model.Band;
import com.techelevator.model.Notification;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@RestController
@CrossOrigin
@PreAuthorize("isAuthenticated()")
public class NotificationController {
    private final NotificationDao notificationDao;
    private final UserDao userDao;
    private final BandDao bandDao;

    public NotificationController(NotificationDao notificationDao, UserDao userDao, BandDao bandDao) {
        this.notificationDao = notificationDao;
        this.userDao = userDao;
        this.bandDao = bandDao;
    }

    @GetMapping("/inbox")
    public List<Notification> getAllNotifications(Principal principal) {
        int userId = userDao.getUserByUsername(principal.getName()).getId();
        return notificationDao.getAllNotifications(userId);
    }
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping("/bands/{bandId}/sendMessage")
    public Notification createNotification(@PathVariable int bandId, @RequestBody Notification notification){
       notification.setBandId(bandId);
       notification.setDateSent(LocalDateTime.now());
       return notificationDao.createNotification(notification);
    }
}
