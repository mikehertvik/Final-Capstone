package com.techelevator.model;

import java.time.LocalDateTime;

public class Notification {
    private int notifId;
    private String notifMessage;
    private LocalDateTime dateSent;
    private int bandId;
    private String notifSubject;
    private String bandName;

    public Notification(int notifId, String notifMessage, LocalDateTime dateSent, int bandId, String notifSubject, String bandName) {
        this.notifId = notifId;
        this.notifMessage = notifMessage;
        this.dateSent = dateSent;
        this.bandId = bandId;
        this.notifSubject = notifSubject;
        this.bandName = bandName;
    }

    public Notification(){

    };

    public int getNotifId() {
        return notifId;
    }

    public void setNotifId(int notifId) {
        this.notifId = notifId;
    }

    public String getNotifMessage() {
        return notifMessage;
    }

    public void setNotifMessage(String notifMessage) {
        this.notifMessage = notifMessage;
    }

    public LocalDateTime getDateSent() {
        return dateSent;
    }

    public void setDateSent(LocalDateTime dateSent) {
        this.dateSent = dateSent;
    }

    public int getBandId() {
        return bandId;
    }

    public void setBandId(int bandId) {
        this.bandId = bandId;
    }

    public String getNotifSubject() {
        return notifSubject;
    }

    public void setNotifSubject(String notifSubject) {
        this.notifSubject = notifSubject;
    }

    public String getBandName() {
        return bandName;
    }

    public void setBandName(String bandName) {
        this.bandName = bandName;
    }
}
