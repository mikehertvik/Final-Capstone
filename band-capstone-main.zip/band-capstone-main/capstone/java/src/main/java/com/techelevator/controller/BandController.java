package com.techelevator.controller;

import com.techelevator.dao.BandDao;
import com.techelevator.dao.UserDao;
import com.techelevator.exception.DaoException;
import com.techelevator.model.Band;
import com.techelevator.model.User;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@PreAuthorize("isAuthenticated()")
@CrossOrigin
public class BandController {
    
    private final BandDao bandDao;
    private final UserDao userDao;

    public BandController(BandDao bandDao, UserDao userDao) {
        this.bandDao = bandDao;
        this.userDao = userDao;
    }

    @GetMapping("/bands/random")
    public List<Band> getRandomBands() {
        int count = 3;
        return bandDao.getRandomBands(count);
    }

    @GetMapping("/bands/{bandId}")
    public Band getBandById(@PathVariable int bandId, Principal principal) {
        int userId = userDao.getUserByUsername(principal.getName()).getId();
        return bandDao.getBandById(bandId, userId);
    }

    @GetMapping("/bands")
    public List<Band> getBandsByName(@RequestParam(required = false) String name, Principal principal) {
        int userId = userDao.getUserByUsername(principal.getName()).getId();
        if(name == null) {

            return bandDao.getAllBands(userId);
        } else {

            return bandDao.getBandsByName(name, userId);
        }

    }
    @PostMapping("/band")
    public ResponseEntity<Band> createBand(@RequestBody Band band, Principal principal) {
        try {
            if (principal == null) {
                throw new DaoException("User not authenticated. Principal is null.");
            }

            // Get the user creating the band
            User user = userDao.getUserByUsername(principal.getName());
            if (user == null) {
                throw new DaoException("No user found for username: " + principal.getName());
            }

            band.setCreator(user.getId()); // Set the user ID as creator

            // Create the band
            Band createdBand = bandDao.createBand(band, user.getId());
            return ResponseEntity.status(HttpStatus.CREATED).body(createdBand);

        } catch (Exception e) {
            e.printStackTrace();
            throw new DaoException("Unable to create band.", e);
        }
    }

    @PutMapping("/band/{id}")
    public ResponseEntity<Band> updateBand(@PathVariable int id, @RequestBody Band band, Principal principal) {
        try {
            int userId = userDao.findIdByUsername(principal.getName());

            // Set the path id into the band object
            band.setBandId(id);

            // --- SET CREATOR FIELD INTO BAND OBJECT ---
            band.setCreator(userId);

            // Call DAO with just band (no userId separately)
            Band updatedBand = bandDao.updateBand(band);

            return ResponseEntity.ok(updatedBand);

        } catch (DaoException e) {
            String message = e.getMessage();
            if (message != null && message.contains("No band found to update")) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).build(); // 403 if not allowed
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 500 for other DB issues
            }
        }
    }




}
