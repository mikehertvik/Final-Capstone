package com.techelevator.dao;

import com.techelevator.exception.DaoException;
import com.techelevator.model.Band;
import com.techelevator.model.User;
import com.techelevator.model.Follow;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;



import java.util.ArrayList;
import java.util.List;

@Component
public class JdbcBandDao implements BandDao{
    private final JdbcTemplate jdbcTemplate;

    public JdbcBandDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Band> getRandomBands(int count) {
        List<Band> randomBands = new ArrayList<>();
        String sql = "SELECT b.band_id, b.name AS band_name, b.creator, b.bio, b.profile_img, b.banner_img " +
                "FROM band b ORDER BY RANDOM() LIMIT ?;";

        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, count);
            while (results.next()) {
                Band band = new Band();
                band.setBandId(results.getInt("band_id"));
                band.setName(results.getString("band_name"));
                band.setBio(results.getString("bio"));
                band.setCreator(results.getInt("creator"));
                band.setBannerImg(results.getString("banner_img"));
                band.setProfileImg(results.getString("profile_img"));
                randomBands.add(band);
            }
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to the database", e);
        } catch (Exception e) {
            e.printStackTrace();
            throw new DaoException("Error retrieving random bands", e);
        }

        return randomBands;
    }
    @Override
    public Band getBandByName(String name, int userId) {
        Band band = null;
        String bandSql = "SELECT " +
        "b.band_id, " +
        "b.name AS band_name, " +
        "b.creator, " +
        "b.bio, " +
        "b.profile_img, " +
        "b.banner_img, " +
        "f.user_id IS NOT NULL AS userFollowing " +
        "FROM band b " +
        "LEFT JOIN following f ON b.band_id = f.band_id AND f.user_id = ?" +
        "WHERE LOWER(b.name) = LOWER(?)";


        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(bandSql, userId, name);
            if (results.next()) {
                band = mapRowToBand(results);
            }
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to database", e);
        }

        return band;
}
// Not used, just commenting out so I don't confuse myself
//    private List<String> getGenresByBandId(int bandId) {
//        List<String> genres = new ArrayList<>();
//        String sql = "SELECT g.genre_name " +
//                "FROM genre g " +
//                "JOIN band_genre bg ON g.genre_id = bg.genre_id " +
//                "WHERE bg.band_id = ?;";
//
//        try {
//            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, bandId);
//            while (results.next()) {
//                genres.add(results.getString("genre_name"));
//            }
//        } catch (CannotGetJdbcConnectionException e) {
//            throw new DaoException("Unable to connect to database", e);
//        }
//
//        return genres;
//    }

    @Override
    public List<Band> getBandsByName(String bandName, int userId) {
        List<Band> bands = new ArrayList<>();
        String bandSql = "%" + bandName + "%";
        
        String sql ="SELECT " +
                "b.band_id, " +
                "b.name AS band_name, " +
                "b.creator, " +
                "b.bio, " +
                "b.profile_img, " +
                "b.banner_img, " +
                "f.user_id IS NOT NULL AS userFollowing " +
                "FROM band b " +
                "LEFT JOIN following f ON b.band_id = f.band_id AND f.user_id = ?" +
                "WHERE b.name ILIKE ? " +
                "ORDER BY b.name ASC;";

        String genreSql = "SELECT g.name FROM genres g " +
                "JOIN band_genre bg ON g.genre_id = bg.genre_id " +
                "WHERE bg.band_id = ?;";
        try{
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, userId, bandSql);
            while (results.next()) {
                Band band = mapRowToBand(results);
                int bandId = band.getBandId();
                List<String> genres = new ArrayList<>();
                SqlRowSet genreResults = jdbcTemplate.queryForRowSet(genreSql, bandId);
                while (genreResults.next()) {
                    genres.add(genreResults.getString("name"));
                }
                band.setGenres(genres);
                bands.add(band);
            }
        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }
        return bands;
    }
    @Override
    public List<Band> getAllBands(int userId) {
        List<Band> bands = new ArrayList<>();
        String bandSql ="SELECT " +
                "b.band_id, " +
                "b.name AS band_name, " +
                "b.creator, " +
                "b.bio, " +
                "b.profile_img, " +
                "b.banner_img, " +
                "f.user_id IS NOT NULL AS userFollowing " +
                "FROM band b " +
                 "LEFT JOIN following f ON f.band_id = b.band_id  AND f.user_id = ?" +
                "ORDER BY b.name ASC;";

        String genreSql = "SELECT g.name FROM genres g " +
                "JOIN band_genre bg ON g.genre_id = bg.genre_id " +
                "WHERE bg.band_id = ?;";



              try{
            SqlRowSet bandResults = jdbcTemplate.queryForRowSet(bandSql, userId);
            while (bandResults.next()) {
                Band band = mapRowToBand(bandResults);
                int bandId = band.getBandId();
                List<String> genres = new ArrayList<>();
                SqlRowSet genreResults = jdbcTemplate.queryForRowSet(genreSql, bandId);
                while (genreResults.next()) {
                    genres.add(genreResults.getString("name"));
                }
                band.setGenres(genres);
                bands.add(band);
                  }
        } catch(CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }
        return bands;
    }


    private Band mapRowToBand(SqlRowSet rs) {
        Band band = new Band();
        band.setBandId(rs.getInt("band_id"));
        band.setName(rs.getString("band_name"));
        band.setBio(rs.getString("bio"));
        band.setCreator(rs.getInt("creator"));
        band.setBannerImg(rs.getString("banner_img"));
        band.setProfileImg(rs.getString("profile_img"));
        band.setUserFollowing(rs.getBoolean("userFollowing"));
        return band;
    }

    @Override
    public Band createBand(Band band, int userId) {
        String insertBandSql = "INSERT INTO band (name, bio, banner_img, profile_img, creator) " +
                "VALUES (?, ?, ?, ?, ?) RETURNING band_id;";

        try {
            int newBandId = jdbcTemplate.queryForObject(insertBandSql, int.class,
                    band.getName(),
                    band.getBio(),
                    band.getBannerImg(),
                    band.getProfileImg(),
                    userId
            );

            // 🆕 Insert all genres if provided
            if (band.getGenreIds() != null && !band.getGenreIds().isEmpty()) {
                for (Integer genreId : band.getGenreIds()) {
                    String insertBandGenreSql = "INSERT INTO band_genre (band_id, genre_id) VALUES (?, ?);";
                    jdbcTemplate.update(insertBandGenreSql, newBandId, genreId);
                }
            }

            band.setBandId(newBandId);
            band.setCreator(userId);
            return band;

        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        }
    }



    @Override
    public Band getBandById(int bandId, int userId) {
        Band band = null;
        String bandSql = "SELECT b.band_id, b.name AS band_name, b.creator, b.bio, b.profile_img, b.banner_img, " +
                "f.user_id IS NOT NULL AS userFollowing " +
                "FROM band b " +
                "LEFT JOIN following f ON b.band_id = f.band_id AND f.user_id = ?" +
                "WHERE b.band_id = ?;";

        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(bandSql, userId, bandId);
            if (results.next()) {
                band = mapRowToBand(results);

                // Fetch genres from band_genre
                String genreSql = "SELECT g.name FROM genres g " +
                        "JOIN band_genre bg ON g.genre_id = bg.genre_id " +
                        "WHERE bg.band_id = ?;";

                List<String> genres = new ArrayList<>();
                SqlRowSet genreResults = jdbcTemplate.queryForRowSet(genreSql, bandId);
                while (genreResults.next()) {
                    genres.add(genreResults.getString("name"));
                }

                band.setGenres(genres);
            }
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to database", e);
        }
        return band;
    }

    @Override
    public Band updateBand(Band band) {
        String updateBandSql = "UPDATE band " +
                "SET name = ?, bio = ?, banner_img = ?, profile_img = ? " +
                "WHERE band_id = ? AND creator = ?;";

        String deleteBandGenresSql = "DELETE FROM band_genre WHERE band_id = ?;";
        String insertBandGenreSql = "INSERT INTO band_genre (band_id, genre_id) VALUES (?, ?);";

        try {
            int rowsAffected = jdbcTemplate.update(updateBandSql,
                    band.getName(),
                    band.getBio(),
                    band.getBannerImg(),
                    band.getProfileImg(),
                    band.getBandId(),
                    band.getCreator()
            );

            if (rowsAffected == 0) {
                throw new DaoException("No band found to update or user is not the creator.");
            }

            //Clear old genres
            jdbcTemplate.update(deleteBandGenresSql, band.getBandId());

            //Insert new genres
            if (band.getGenreIds() != null && !band.getGenreIds().isEmpty()) {
                for (Integer genreId : band.getGenreIds()) {
                    jdbcTemplate.update(insertBandGenreSql, band.getBandId(), genreId);
                }
            }

            return band;

        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Database connection error while updating band", e);
        }
    }





}
