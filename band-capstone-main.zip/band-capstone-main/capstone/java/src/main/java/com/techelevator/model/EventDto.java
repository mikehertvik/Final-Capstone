package com.techelevator.model;

import java.time.LocalDateTime;

public class EventDto {
    private int eventId;
    private int bandId;
    private String eventName;
    private String eventVenue;
    private String eventAddress;
    private LocalDateTime eventDateTime;


    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getBandId() {
        return bandId;
    }

    public void setBandId(int bandId) {
        this.bandId = bandId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventVenue() {
        return eventVenue;
    }

    public void setEventVenue(String eventVenue) {
        this.eventVenue = eventVenue;
    }

    public String getEventAddress() {
        return eventAddress;
    }

    public void setEventAddress(String eventAddress) {
        this.eventAddress = eventAddress;
    }

    public LocalDateTime getEventDateTime() {
        return eventDateTime;
    }

    public void setEventDateTime(LocalDateTime eventDateTime) {
        this.eventDateTime = eventDateTime;
    }

    public String toString(Event event) {
        return "EventDto{" +
                "eventName='" + event.getEventName() + '\'' +
                "eventVenue='" + event.getEventVenue() + '\'' +
                "eventAddress='" + event.getEventAddress() + '\'' +
                "eventDateTime='" + event.getEventDateTime() + '\'' +
                '}';
    }
}
