BEGIN TRANSACTION;

-- the password for both users is "password"
INSERT INTO users (username,password_hash,role,email,birthdate) VALUES ('user','$2a$08$UkVvwpULis18S19S5pZFn.YHPZt3oaqHZnDwqbCW9pft6uFtkXKDC','ROLE_USER','user@example.com','2000-01-01');
INSERT INTO users (username,password_hash,role,email,birthdate) VALUES ('admin','$2a$08$UkVvwpULis18S19S5pZFn.YHPZt3oaqHZnDwqbCW9pft6uFtkXKDC','ROLE_ADMIN','admin@example.com','2000-01-01');
--INSERT INTO users (username,password_hash,role,birthdate) VALUES ('user@example.com','$2a$08$UkVvwpULis18S19S5pZFn.YHPZt3oaqHZnDwqbCW9pft6uFtkXKDC','ROLE_USER','2000-01-01');
--INSERT INTO users (username,password_hash,role,birthdate) VALUES ('admin@example.com','$2a$08$UkVvwpULis18S19S5pZFn.YHPZt3oaqHZnDwqbCW9pft6uFtkXKDC','ROLE_ADMIN','2000-01-01');

INSERT INTO genres (name) VALUES ('Pop');
INSERT INTO genres (name) VALUES ('Classic Rock');
INSERT INTO genres (name) VALUES ('Classical');
INSERT INTO genres (name) VALUES ('Indie');
INSERT INTO genres (name) VALUES ('Country');
INSERT INTO genres (name) VALUES ('EDM');
INSERT INTO genres (name) VALUES ('Hip-Hop');

INSERT INTO band (name, genre_id, creator, bio, profile_img, banner_img) VALUES ('The Wiggles', 1, 1, 'Wiggle wiggle wiggle', 'https://images.squarespace-cdn.com/content/v1/607e2958f193931b35b01977/6823a184-e8d9-483e-a600-fef23b9ee166/Header.png', 'https://static.vecteezy.com/system/resources/previews/000/694/606/original/abstract-colorful-geometric-banner-template-background-vector.jpg'),
('Teletubbies', 1, 1, 'Weve got tvs in our tummies', 'https://i.ytimg.com/vi/zXfzzxH1q8o/maxresdefault.jpg', ' '),
('Barney and Friends', 1, 1, 'The Purplest Dinosaur you will ever meet', 'https://www.tvinsider.com/wp-content/uploads/2022/04/barney-and-friends-demi-lovato-selena-gomez-1014x570.jpeg', 'https://img.texasmonthly.com/2020/10/hollywood-tx-barney.jpg?auto=compress&crop=faces&fit=crop&fm=jpg&h=900&ixlib=php-3.3.1&q=45&w=1600'),
('Seasame Street', 1, 1, 'We make music on the streets', 'https://sesameworkshop.org/wp-content/uploads/2023/03/SesameStreetShow_small.png', 'https://i.ytimg.com/vi/tMwlpKpSHic/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBy04CT1I3HR8LgIgxe38FHaBeN-A'),
('Hertveoke', 2, 3, 'The worlds premiere cover band where all the lyrics are wrong!', 'https://images.pexels.com/photos/167636/pexels-photo-167636.jpeg?auto=compress&cs=tinysrgb&w=800', 'https://images.pexels.com/photos/995301/pexels-photo-995301.jpeg?auto=compress&cs=tinysrgb&w=800'),
('Broken Levy', 2, 3, 'When the leveies break its a flood!!!', 'https://media.licdn.com/dms/image/v2/C5603AQETgmHGKktm9g/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1517741523223?e=1751500800&v=beta&t=KemJaE37lp-JyckXq-OYqAjzCCX-PHnVRVJqXoawKDQ', 'https://aarp-content.brightspotcdn.com/dims4/default/8a07d5a/2147483647/strip/true/crop/1279x704+0+0/resize/876x482!/quality/90/?url=http%3A%2F%2Faarp-brightspot.s3.amazonaws.com%2Fcontent%2F9d%2Fc5%2F3cc69df34095b2859b28dde04cc0%2Fdadband-nateryan-41280x704.jpg'),
('Dave and the McKenzies', 3, 3, 'Just Dave all up in here!', 'https://www.al-monitor.com/sites/default/files/styles/article_hero_medium/public/almpics/2020/02/RTS7K7V.jpg/RTS7K7V.jpg?h=a5ae579a&itok=v9C2FeFX', 'https://journals.openedition.org/ema/docannexe/image/14794/img-6.jpg'),
('Golden and the Retrievers', 4, 3, 'We are the best dog breed!','https://preview.redd.it/activities-for-a-golden-retriever-puppy-v0-s48pd68dyczd1.jpeg?auto=webp&s=b87309f9c34f906f742d7b24f1aa586551606572', 'https://media.zenfs.com/en/pethelpful_915/33112f8c039dc0e3d75bf44ca8560cdf'),
('Kovacks and Pals', 1, 3, 'Nothing but bros here', 'https://images.pexels.com/photos/210887/pexels-photo-210887.jpeg?auto=compress&cs=tinysrgb&w=800', 'https://images.pexels.com/photos/210887/pexels-photo-210887.jpeg?auto=compress&cs=tinysrgb&w=800'),
('The Skye Hall Experience ', 5, 3, 'Just be Skye', 'https://t3.ftcdn.net/jpg/04/48/60/42/360_F_448604211_Mdn3hNw4oKxa5IBA4VUOx0nMndxae7UB.jpg', 'https://ca-times.brightspotcdn.com/dims4/default/bdd5805/2147483647/strip/true/crop/4200x2799+0+1/resize/2000x1333!/quality/75/?url=https%3A%2F%2Fcalifornia-times-brightspot.s3.amazonaws.com%2F89%2F40%2F54112c9a4293bfd2e4b737d2d405%2F20230709-lat-dadjamband-113.jpg');

INSERT INTO following (user_id, band_id) VALUES (1, 1);
INSERT INTO following (user_id, band_id) VALUES (1, 2);
INSERT INTO following (user_id, band_id) VALUES (1, 3);

INSERT INTO band_genre (band_id, genre_id)
VALUES (1, 3), (4, 5), (5, 6), (6, 7), (7, 4), (8, 2), (9, 1), (10, 4);
INSERT INTO band_genre (band_id, genre_id)
VALUES (2, 2), (3, 6), (6, 5), (4, 2);
INSERT INTO band_genre (band_id, genre_id) VALUES (3, 1);

INSERT INTO notifications (notif_message, date_sent, band_id, notif_subject)
VALUES('We’re cooking up something special behind the scenes. Get ready for a whole new side of Broken Levy.','2025-4-20 10:00:00', 6, 'Something is coming'),
('Broken Levy just dropped their new single "Shadows Run Deep"—now streaming everywhere', '2025-05-02 9:00:00', 6, 'New Single!'),
('Barney is up to something exciting! Keep your eyes peeled for what’s coming—we promise it’ll be worth the wait.', '2025-04-28 10:58:00', 3, 'Get Excited!'),
('Barney’s bringing the energy—turn up the volume and let’s make some noise together! It’s going to be a blast.', '2025-05-02 8:59:00', 3, 'New Concert!');

INSERT INTO gallery (img_url, band_id)
VALUES ('https://tse3.mm.bing.net/th/id/OIP.peA5ILCfebCRr2LRch1BoAHaFj?rs=1&pid=ImgDetMain', 1);

INSERT INTO events (event_name, event_venue, event_address, event_date_time, band_id)
VALUES ('Test Event 1', 'Rock and Roll Hall of Fame', '1100 E 9th St, Cleveland, OH 44114', '2025-04-29 11:00:00', 1)
, ('Test Event 2', 'Rock and Roll Hall of Fame', '1100 E 9th St, Cleveland, OH 44114', '2025-04-29 10:00:00', 1);

INSERT INTO gallery(img_url, band_id)
VALUES('http://i1.sndcdn.com/artworks-000165581257-muhb8x-t500x500.jpg', 3),
('https://images.entertainment.ie/storage/images_content/rectangle/620x372/2016-06-22-12_09_57-The-Notorious-BIG-_-Big-Poppa-_-Barney-M.png?w=640&h=384&q=high', 3),
('https://media-cldnry.s-nbcnews.com/image/upload/t_fit-760w,f_auto,q_auto:best/rockcms/2022-10/221004-barney-dinosaur-al-1132-c8ea46.jpg', 3);

COMMIT TRANSACTION;
