BEGIN TRANSACTION;

DROP TABLE IF EXISTS following;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS gallery;
DROP TABLE IF EXISTS band;
DROP TABLE IF EXISTS genres;

CREATE TABLE users (
	user_id SERIAL,
	username varchar(50) NOT NULL UNIQUE,
	password_hash varchar(200) NOT NULL,
	role varchar(50) NOT NULL,
	email varchar(100),
	birthdate date NOT NULL,
	last_inbox_check TIMESTAMP,
	CONSTRAINT PK_user PRIMARY KEY (user_id)
);

CREATE TABLE genres (
    genre_id SERIAL NOT NULL PRIMARY KEY,
    name varchar(200) UNIQUE NOT NULL,
    CONSTRAINT UQ_name UNIQUE (name)
);

CREATE TABLE band (
    band_id SERIAL NOT NULL PRIMARY KEY,
    name varchar(200) NOT NULL,
    genre_id INTEGER,
    creator INTEGER NOT NULL,
    bio varchar(2000),
    profile_img varchar(2000),
    banner_img varchar(2000),



    CONSTRAINT fk_genres_genre_id_band FOREIGN KEY (genre_id) REFERENCES genres(genre_id)
);

CREATE TABLE following (
    user_id INTEGER NOT NULL,
    band_id INTEGER NOT NULL,

    CONSTRAINT fk_users_user_id_following FOREIGN KEY (user_id) REFERENCES users(user_id),
    CONSTRAINT fk_bands_band_id_following FOREIGN KEY (band_id) REFERENCES band(band_id),
    CONSTRAINT Pk_user_id_band_id PRIMARY KEY (user_id, band_id)
);
CREATE TABLE band_genre (
    band_id INTEGER NOT NULL,
    genre_id INTEGER NOT NULL,
    PRIMARY KEY (band_id, genre_id),
    FOREIGN KEY (band_id) REFERENCES band(band_id),
    FOREIGN KEY (genre_id) REFERENCES genres(genre_id)
);

CREATE TABLE notifications (
    notif_id SERIAL,
    notif_subject VARCHAR(100),
    notif_message VARCHAR(2000) NOT NULL,
    date_sent TIMESTAMP NOT NULL,
    band_id INTEGER NOT NULL,
    CONSTRAINT PK_notif PRIMARY KEY (notif_id),
    CONSTRAINT FK_band_notif FOREIGN KEY (band_id) REFERENCES band(band_id)
);

CREATE TABLE gallery (
    img_id SERIAL NOT NULL PRIMARY KEY,
    img_url varchar(2000) NOT NULL,
    band_id INTEGER NOT NULL,

    CONSTRAINT fk_band_band_id_gallery FOREIGN KEY (band_id) REFERENCES band(band_id)
);

CREATE TABLE events (
    event_id SERIAL PRIMARY KEY,
    event_name varchar(200) NOT NULL,
    event_venue varchar(200) NOT NULL,
    event_address varchar(200) NOT NULL,
    event_date_time TIMESTAMP NOT NULL,
    band_id INTEGER NOT NULL,

    CONSTRAINT fk_band_events FOREIGN KEY (band_id) REFERENCES band(band_id)
);


COMMIT TRANSACTION;
