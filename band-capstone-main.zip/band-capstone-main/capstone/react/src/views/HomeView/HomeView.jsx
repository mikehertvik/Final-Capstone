import { useContext, useState, useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { UserContext } from '../../context/UserContext';
import BandCard from '../../components/BandCard/BandCard';
import BandService from '../../services/BandService';
import styles from './HomeView.module.css';


export default function HomeView() {
  const [band, setBands] = useState([]);
  const user = useContext(UserContext);
  console.log(user);
  console.log("FFFFFF");
  const [isLoading, setIsLoading] = useState(true);
  const { id } = useParams();
  const bandId = id;
  const navigate = useNavigate();

  function getPageData() {
    setIsLoading(true);
    BandService.getRandomBands(3)
      .then((response) => {
        setBands(response.data);
        setIsLoading(false);
        console.log(user);
      })
      .catch((error) => {
        const errorMessage = error.response ? error.response.data.message : error.message;
        console.error(errorMessage);
        setIsLoading(false);
      });
  }

  useEffect(() => {
    getPageData();
  }, []);


  return (
    <>{isLoading ? (
      <p className={styles.homepage}>Loading...</p>
    ) : (
      <>
        <div className={styles.homepage}>
          {user ? (
            <div>
              <h1 className={styles.title}>SoundBridge</h1>
              <h3 className={styles.subHeader}>Connect with a new band</h3>

              <div className={styles.cardGrid}>
                <ul className={styles.searchResults}>
                  {band.length > 0 ? (
                    band.map((bands) => (
                      <li className={styles.bandCard} key={bands.bandId} >{/* follow/unfollow button */}
                        <BandCard band={bands} />
                      </li>
                    ))) : (
                    <p className={styles.noResults}>No bands found matching your criteria</p>
                  )}
                </ul>
              </div>
              <div className={styles.searchBar}>
                <Link to="/bands"><button className={styles.searchBands}>Search for Bands</button></Link>
              </div>
            </div>
          ) : (
            <div className={styles.loggedOutPage}>
              <h1>Page not found.</h1>
              <button onClick={() => navigate('/login')}>Return to Login</button></div>
          )}
        </div>
      </>
    )}
    </>
  );
}