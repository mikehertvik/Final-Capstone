import { useEffect, useState, useContext } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import styles from './BandView.module.css';
import { UserContext } from '../../context/UserContext';
import FollowService from '../../services/FollowService';
import BandService from '../../services/BandService';
import GalleryService from '../../services/GalleryService';
import Events from '../../components/Events/Events';

export default function BandView() {
  const user = useContext(UserContext);
  const { bandId } = useParams();
  const navigate = useNavigate();
  const [band, setBand] = useState(null);
  const [error, setError] = useState('');
  const [followStatus, setFollowStatus] = useState(false);
  const [followerCount, setFollowerCount] = useState(0);
  const [gallery, setGallery] = useState(null);
  const [listEvents, setListEvents] = useState(true);
 


  useEffect(() => {
    user && BandService.getBandById(bandId)
      .then(response => {
        setBand(response.data);
        FollowService.isFollowing(response.data.bandId).then(response => { setFollowStatus(response.data); }).catch();
        FollowService.getFollowerCount(response.data.bandId).then(response => setFollowerCount(response.data)).catch(error => console.error('Error fetching follower count:', error));
        setError('');
        setListEvents(false);
        // EventService.getAllEvents(response.data.bandId).then(response => setEvents(response.data)).catch();
      })
      .catch(error => {
        console.error(error);
        setError('Band not found.');
      });

      user && GalleryService.getGalleryByBandId(bandId)
      .then(response => {
        setGallery(response.data);
        setError('');
      })
      .catch(error => {
        console.error(error);
        setError('Band not found.');
      });

  }, [user, bandId]);


  if (error) {
    return (
      <div className={styles.pageContainer}>
        <h2>{error}</h2>
        <button className={styles.backButton} onClick={() => navigate('/')}>Back to Home</button>
      </div>
    );
  }

  if (!band) {
    return (
      <div className={styles.pageContainer}>
        <h2>Loading...</h2>
      </div>
    );
  }

  // handle events contents appearing
  function handleEventButton(){
    console.log(listEvents);
    if (listEvents){
      setListEvents(false);
      console.log(listEvents);
    } else {
      setListEvents(true);
      console.log(listEvents);
    }
  }

  //to add follower to database
  function handleFollow() {
    let bandId = band.bandId;
    if (followStatus) {
      FollowService.unfollowBand(bandId)
      .then((response) => {
        setFollowStatus(response.data);
        window.location.reload();
      })
      .catch((error) => {
        const message = error.response?.data?.message || error.message;
        console.error(`Error unfollowing band: ${message}`);
        setNotification({ type: 'error', message: 'Failed to unfollow.' });
      });
        setFollowStatus(FollowService.isFollowing(bandId));
    } else {
      // follow band
      FollowService.followBand(bandId)
        .then((response) => {
          // setFollowStatus(response.data);
          window.location.reload();

        })
        .catch((error) => {
          const message = error.response?.data?.message || error.message;
          console.error(`Error following band: ${message}`);
          //  setNotification({ type: 'error', message: 'Failed to follow.' });
        });
      setFollowStatus(FollowService.isFollowing(bandId));
    }
  }

  function handleEditClick() {
    navigate(`/update-band/${band.bandId}`);
  }

  return (
    <div className={styles.pageContainer}>
      {/* Cover Image */}
      {band.bannerImg && (
        <img src={band.bannerImg} alt={`${band.name} Banner`} className={styles.bannerImage} />
      )}

      <div className={styles.profileContainer}>
        {band.profileImg && (
          <img src={band.profileImg} alt={`${band.name} Profile`} className={styles.profileImage} />
        )}
        <div className={styles.followerCount}>
          {followerCount} followers
        </div>
      </div>


      {/* Follow/unfollow band button */}
      <button className={styles.followButton} onClick={handleFollow}>{followStatus ? "-" : "+"}</button>

      {/* Band Name */}
      <h1 className={styles.bandName}>{band.name}</h1>

      {/* Genre(s) */}
      <div className={styles.genreContainer}>
        {band.genres && band.genres.map((genre, index) => (
                    <span key={index} className={styles.genreBadge}>
                        {genre}
                    </span>
                ))}
        </div>
  
        {/* Bio section */}
        <div className={styles.bioCard}>
          <h2 className={styles.bioHeader}>Bio</h2>
          <p className={styles.bioText}>{band.bio}</p>
        </div>
  
        {/* Send Message Link */}
        {band.creator === user.id ? (
          <div className={styles.messageContainer}>
            <ul className={styles.creatorButtons}>

              <li>
                <Link className={styles.messageLink} to={`/bands/${band.bandId}/sendMessage`}>Message Followers</Link>
              </li>

              <li>
                {/* 🆕 NEW: Edit Button - Only for creator */}
          {user && band.creator === user.id && (
              <button className={styles.editButton} onClick={handleEditClick}>
                Edit Band
              </button>
            )}
              </li>

              <li>
              <Link className={styles.messageLink} to={`/bands/${band.bandId}/gallery`}>Add Image To Gallery</Link>
              </li>

              <li className={styles.addEvent}>
              <Link className={styles.messageLink} to={`/bands/${band.bandId}/events/add`}>Add An Event</Link>
              </li>
              
           </ul>
        </div>
        ) : (
          <p></p>
        )}
        <button className={styles.showEvents} onClick={handleEventButton} >
          Click Here To View Upcoming Events
        </button>
       <div className={styles.eventsContainer}> { listEvents? <Events /> : <p className={styles.noList}></p>} </div>
      <div className={styles.gallery}>
      <ul className={styles.imageList}>
        {gallery && gallery.map((image) => (
            <li key={gallery.imageId} className={styles.imgContainer}>
              <img src={`${image.imgUrl}`} className={styles.galleryImage}></img>
            </li>
        ))
        }
      </ul>
      </div>
      </div>
      
    );

}