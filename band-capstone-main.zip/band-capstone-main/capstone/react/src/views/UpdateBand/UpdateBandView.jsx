import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import BandService from "../../services/BandService";
import GenreService from "../../services/GenreService";
import "./UpdateBand.css";

export default function UpdateBandView() {
  const { bandId } = useParams();
  const navigate = useNavigate();

  const [bandName, setBandName] = useState("");
  const [description, setDescription] = useState("");
  const [profileImage, setProfileImage] = useState("");
  const [bannerImage, setBannerImage] = useState("");
  const [genres, setGenres] = useState([]);
  const [selectedGenres, setSelectedGenres] = useState([]);

  useEffect(() => {
    // Fetch band info
    BandService.getBandById(bandId)
      .then((response) => {
        const band = response.data;
        setBandName(band.name || "");
        setDescription(band.bio || "");
        setProfileImage(band.profileImg || "");
        setBannerImage(band.bannerImg || "");
        if (band.genreIds) {
          setSelectedGenres(band.genreIds);
        }
      })
      .catch((error) => {
        console.error("Failed to fetch band:", error);
      });

    // Fetch all genres
    GenreService.getAllGenres()
      .then((response) => {
        setGenres(response.data);
      })
      .catch((error) => {
        console.error("Failed to load genres:", error);
      });
  }, [bandId]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const updatedBand = {
      name: bandName,
      bio: description,
      profileImg: profileImage,
      bannerImg: bannerImage,
      genreIds: selectedGenres,
    };

    BandService.updateBand(bandId, updatedBand)
      .then(() => {
        navigate(`/bands/${bandId}`);
        window.location.reload();
      })
      .catch((error) => {
        console.error("Failed to update band:", error);
      });
  };

  return (
    <div className="updateBandContainer">
      <h2 className="updateBandTitle">Update Band</h2>

      <form onSubmit={handleSubmit} className="bandForm">
        <label>Band Name:</label>
        <input
          type="text"
          value={bandName}
          onChange={(e) => setBandName(e.target.value)}
          required
        />

        <label>Description:</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows="5"
        />

        <label>Profile Image URL:</label>
        <input
          type="text"
          value={profileImage}
          onChange={(e) => setProfileImage(e.target.value)}
          required
        />

        <label>Banner Image URL:</label>
        <input
          type="text"
          value={bannerImage}
          onChange={(e) => setBannerImage(e.target.value)}
          required
        />

        <label>Genres:</label>
        <select
          multiple
          value={selectedGenres}
          onChange={(e) => {
            const options = Array.from(e.target.selectedOptions, option => Number(option.value));
            setSelectedGenres(options);
          }}
          required
        >
          {genres.map((g) => (
            <option key={g.genreId} value={g.genreId}>
              {g.name}
            </option>
          ))}
        </select>

        <button type="submit" className="submitButton">
          Update Band
        </button>
      </form>
    </div>
  );
}
