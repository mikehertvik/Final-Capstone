

export default function DeleteEvent(){
    return(
        <>
        </>
    )
}