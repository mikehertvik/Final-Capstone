import { useContext, useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import EventService from "../../services/EventService";
import { UserContext } from '../../context/UserContext';
import styles from './EventView.module.css';
import BandService from '../../services/BandService';


export default function EditEvent() {
  const { bandId, eventId } = useParams();
  const navigate = useNavigate();
  const user = useContext(UserContext);
  const [eventName, setEventName] = useState("");
  const [eventVenue, setEventVenue] = useState("");
  const [eventAddress, setEventAddress] = useState("");
  const [eventDateTime, setEventDateTime] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [band, setBand] = useState();


  useEffect(() => {

    user && EventService.getEventById(eventId)
    .then((response) => {
      const event = response.data;
      setEventName(event.eventName || "");
      setEventVenue(event.eventVenue || "");
      setEventAddress(event.eventAddress || "");
      setEventDateTime(event.eventDateTime || "");
      setIsLoading(false);
    })
    .catch((error) => {
      console.error("Failed to load event:", error);
    });

    user && BandService.getBandById(bandId)
      .then(response => {
        setBand(response.data);
        setIsLoading(false);
      })
      .catch(error => {
        console.error(error);
        setIsLoading(false);
      });

  }, [user, eventId]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const updatedEvent = {
      eventName: eventName,
      eventVenue: eventVenue,
      eventAddress: eventAddress,
      eventDateTime: eventDateTime
    };

    EventService.updateEvent(bandId, eventId, updatedEvent)
      .then(() => {
        navigate(`/bands/${bandId}`);
        window.location.reload();
      })
      .catch((error) => {
        console.error("Failed to update event:", error);
      });
  };

  return (
    <div className={styles.mainPage}>
    { !isLoading ? (band?.creator === user?.id ? (
    // <div className={styles.mainPage}>
    // <>{isLoading ? (
    //   <p className="">Loading...</p>
    // ) : (band?.creator === user?.id ? (
    <div className={styles.container}>
      <h1 className="updateEventTitle">Update Event</h1>

      <form onSubmit={handleSubmit} className={styles.form}>
        <label>Event Name:</label>
        <input
          type="text"
          value={eventName}
          onChange={(e) => setEventName(e.target.value)}
          required
        />

        <label>Venue:</label>
        <input
          value={eventVenue}
          onChange={(e) => setEventVenue(e.target.value)}
          required
        />

        <label>Address:</label>
        <input
          type="text"
          value={eventAddress}
          onChange={(e) => setEventAddress(e.target.value)}
          required
        />

        <label>Date and Time:</label>
        <input
          type="datetime-local"
          value={eventDateTime}
          onChange={(e) => setEventDateTime(e.target.value)}
          required
        />

        <button type="submit" className={styles.createBandButton}>
          Save Changes
        </button>
      </form>
    </div> 
    ) : ( 
            <>
                <div className={styles.backToHome}>
                <p>Unable to load page</p>
                <button className={styles.backButton} onClick={() => navigate('/')}>Back to Home</button>
                </div>
            </>
   )) : (
    <div className={styles.loading}>Loading...</div>
   )} 
    </div>
    );

}
