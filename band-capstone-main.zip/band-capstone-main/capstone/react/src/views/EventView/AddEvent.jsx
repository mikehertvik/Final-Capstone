import EventService from "../../services/EventService";
import { useState, useEffect, useContext } from "react";
import { useNavigate, useParams } from "react-router-dom";
import BandService from '../../services/BandService';
import styles from './EventView.module.css';
import { UserContext } from '../../context/UserContext';

export default function AddEvent(){

    const [name, setName] = useState('');
    const [venue, setVenue] = useState('');
    const [address, setAddress] = useState('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const navigate = useNavigate();
    const { bandId } = useParams();
    const [band, setBand] = useState();
    const [isLoading, setIsLoading] = useState(true);
    const user = useContext(UserContext);


    useEffect(() => {
        user && BandService.getBandById(bandId)
          .then(response => {
            setBand(response.data);
            setIsLoading(false);
          })
          .catch(error => {
            console.error(error);
            setIsLoading(false);
          });
      }, [user, bandId]);

    function handleSubmit(evt) {
        evt.preventDefault();
        let dateTime = date + 'T' + time;
        console.log(time);
        console.log(date);

        const event = {
            eventName: name,
            eventVenue: venue,
            eventAddress: address,
            eventDateTime: dateTime,

        };
        console.log(event);

        user && EventService.createEvent(bandId, event)
            .then(response => {
                console.log('Event created successfully!', response.data);
                navigate(`/bands/${response.data.bandId}`); // Redirect to homepage after successful creation
            })
            .catch(error => {
                console.error('Error creating event', error);
                setErrorMessage('Failed to create event. Please try again.');
            });
    }


    return (
 <div className={styles.mainPage}>
    { !isLoading ? (band?.creator === user?.id ? (
    <div className={styles.container}>
            <h1>Add A New Event</h1>
            <form className={styles.form} onSubmit={handleSubmit}>
                <div>
                    <label>Event Name:</label>
                    <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
                </div>

                <div>
                    <label>Venue:</label>
                    <input value={venue} onChange={(e) => setVenue(e.target.value)} required></input>
                </div>

                <div>
                    <label>Address:</label>
                    <input type="text" value={address} onChange={(e) => setAddress(e.target.value)} required />
                </div>

                <div>
                    <label>Date:</label>
                    <input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
                </div>

                <div>
                    <label>Time:</label>
                    <input type="time" value={time} onChange={(e) => setTime(e.target.value)} required />
                </div>

                
                <button className={styles.createBandButton} type="submit">Add Event</button>
                {errorMessage && <p className="error">{errorMessage}</p>}
            </form>
        </div>
    ) : ( 
            <>
                <div className={styles.backToHome}>
                <p>Unable to load page</p>
                <button className={styles.backButton} onClick={() => navigate('/')}>Back to Home</button>
                </div>
            </>
   )) : (
    <div className={styles.loading}>Loading...</div>
   )} 
    </div>
    );
}