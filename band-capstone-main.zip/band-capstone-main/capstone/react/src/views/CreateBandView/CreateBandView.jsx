import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import styles from './CreateBand.module.css';

export default function CreateBandView() {
    const [name, setName] = useState('');
    const [bio, setBio] = useState('');
    const [bannerImg, setBannerImg] = useState('');
    const [profileImg, setProfileImg] = useState('');
    const [genres, setGenres] = useState([]);
    const [selectedGenres, setSelectedGenres] = useState([]);
    const [errorMessage, setErrorMessage] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        axios.get('http://localhost:9000/genres')
            .then(response => {
                setGenres(response.data);
            })
            .catch(error => {
                console.error('Error fetching genres:', error);
            });
    }, []);

    function handleSubmit(event) {
        event.preventDefault();

        const newBand = {
            name,
            bio,
            bannerImg,
            profileImg,
            genreIds: selectedGenres
        };

        axios.post('http://localhost:9000/band', newBand)
        .then((response) => {
            const newBandId = response.data.bandId;
            navigate(`/bands/${newBandId}`);
            })
            .catch(error => {
                console.error('Error creating band:', error);
                setErrorMessage('Failed to create band. Please try again.');
            });
    }

    return (
        <div className={styles.pageContainer}>
            <h1>Create a New Band</h1>

            {errorMessage && <p className={styles.errorMessage}>{errorMessage}</p>}

            <form onSubmit={handleSubmit}>
                <div>
                    <label>Band Name:</label>
                    <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    />
                </div>

                <div>
                    <label>Bio:</label>
                    <textarea
                        value={bio}
                        onChange={(e) => setBio(e.target.value)}
                        required
                    />
                </div>

                <div>
                    <label>Banner Image URL:</label>
                    <input
                        type="text"
                        value={bannerImg}
                        onChange={(e) => setBannerImg(e.target.value)}
                        required
                    />
                </div>

                <div>
                    <label>Profile Image URL:</label>
                    <input
                        type="text"
                        value={profileImg}
                        onChange={(e) => setProfileImg(e.target.value)}
                        required
                    />
                </div>

                <div>
                    <label>Genres:</label>
                    <select
                        multiple
                        value={selectedGenres}
                        onChange={(e) => {
                            const options = Array.from(e.target.selectedOptions, option => Number(option.value));
                            setSelectedGenres(options);
                        }}
                        required
                    >
                        {genres.map((genre) => (
                            <option key={genre.genreId} value={genre.genreId}>
                                {genre.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <button type="submit">Create Band</button>
                </div>
            </form>
        </div>
    );
}
