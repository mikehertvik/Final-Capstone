import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthService from '../../services/AuthService';
import Message from '../../components/Message/Message';
import logo from '../../assets/logo.png';


import styles from './RegisterView.module.css';
// import logo from '../../assets/soundbridgelogo.png';

export default function RegisterView() {
  const navigate = useNavigate();

  const [notification, setNotification] = useState(null);

  // Setup state for the registration data
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [email, setEmail] = useState('');
  const [birthdate, setBirthdate] = useState('');

  function handleSubmit(event) {
    event.preventDefault();


    // Validate the form data
    if (password !== confirmPassword) {
      // Passwords don't match, so display error notification
      setNotification({ type: 'error', message: 'Passwords do not match.' });
    } else {
      // If no errors, send data to server
      AuthService.register({
        username,
        password,
        confirmPassword,
    //    role: 'user',
        email,
        birthdate,
      })
        .then(() => {
          setNotification({ type: 'success', message: 'Registration successful' });
          navigate('/login');
        })
        .catch((error) => {
          // Check for a response message, but display a default if that doesn't exist
          const message = error.response?.data?.message || 'Registration failed.';
          setNotification({ type: 'error', message: message });
        });
    }
  }

  return (
    <div className={styles.pageBackground}>
      <h1 className={styles.heading}>SoundBridge</h1>

      <div className={styles.layoutContainer}>
        <img src={logo} alt="SoundBridge Logo" className={styles.logo} />

        <div className={styles.formContainer}>
          <Message notification={notification} clearNotification={() => setNotification(null)} />

          <form className={styles.form}onSubmit={handleSubmit}>
            <div className={styles.formControl}>
              <label htmlFor="username">Email:</label>
              <input
                type="text"
                id="username"
                value={username}
                size="50"
                required
                autoFocus
                autoComplete="username"
                onChange={(event) => setUsername(event.target.value)}
              />
            </div>

            <div className={styles.formControl}>
              <label htmlFor="password">Password:</label>
              <input
                type="password"
                id="password"
                value={password}
                size="50"
                required
                onChange={(event) => setPassword(event.target.value)}
              />
            </div>

            <div className={styles.formControl}>
              <label htmlFor="confirmPassword">Confirm Password:</label>
              <input
                className={styles.confirmPassword}
                type="password"
                id="confirmPassword"
                value={confirmPassword}
                size="50"
                required
                onChange={(event) => setConfirmPassword(event.target.value)}
              />
            </div>

            <div className={styles.formControl}>
                <label htmlFor="email">Confirm Email:</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  size="50"
                  required
                  autoComplete="email"
                  onChange={(event) => setEmail(event.target.value)}
                />
              </div>

            <div className={styles.formControl}>
              <label htmlFor="birthdate">Birthdate:</label>
              <input
                type="date"
                id="birthdate"
                value={birthdate}
                size="50"
                required
                onChange={(event) => setBirthdate(event.target.value)}
              />
            </div>

            <button type="submit" className={`btn-primary ${styles.formButton}`}>
              Register
            </button>

            <div className={styles.signInText}>
              Already have an account? <Link to="/login">sign in</Link>
            </div>
          </form>
        </div>

        <img src={logo} alt="SoundBridge Logo" className={styles.logo} />
      </div>
    </div>
  );
}
