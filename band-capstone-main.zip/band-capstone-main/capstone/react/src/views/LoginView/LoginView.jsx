import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import soundbridgelogo from '../../assets/soundbridgelogo.png';
import AuthService from '../../services/AuthService';
import Message from '../../components/Message/Message';
import axios from 'axios';
import styles from './LoginView.module.css';
import logo from '../../assets/logo.png';


export default function LoginView({ onLogin }) {

  const navigate = useNavigate();
  const [notification, setNotification] = useState(null);

  // Setup state for the registration data
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  function handleSubmit(event) {
    event.preventDefault();


    AuthService.login({ username, password })
      .then((response) => {
        // Grab the user and token
        const user = response.data.user;
        const token = response.data.token;
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

        // Add the login data to local storage
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('token', token);

        // Use the callback to add user to state
        onLogin(user);

        // Navigate to the home page
        navigate('/');
      })
      .catch((error) => {
        let message = 'Login failed.';
  
        // Check for specific error cases
        if (error.response?.status === 401) {
          message = 'Incorrect email or password. Please try again.';
        } else if (error.response?.data?.message) {
          message = error.response.data.message;
        }

        setNotification({ type: 'error', message });
      })
      
  }

  return (
    <div className={styles.viewLogin}>
      
      <Message notification={notification} clearNotification={() => setNotification(null)} />
      <h1 className={styles.title}>SoundBridge</h1>

    <div className={styles.layoutContainer}>
      <img className={styles.logo} src={logo} alt="soundbridgelogo"/>

      <div className={styles.formContainer}>
        <form onSubmit={handleSubmit} className={styles.form}>
          <div className= {styles.formControl}>
            <label htmlFor="email">Email: </label>
            <input type="email" id="email" value={username} size="50" required autoFocus autoComplete="email"
                onChange={ event => setUsername(event.target.value)} />
          </div>

          <div className={styles.formControl}>
            <label htmlFor="password">Password: </label>
            <input type="password" id="password" value={password} size="50" required
              onChange={ event => setPassword(event.target.value)} />
          </div>

          <button type="submit" className={`btn-primary ${styles.formButton}`}>Login</button>
     
          <div className={styles.registerText}> Don't Have An Account? <Link to="/register" className={styles.registerButton}>create an account</Link></div>
        </form>
       </div>

        <img className={styles.logo} src={logo} alt="soundbridgelogo"/>
      </div>   
    </div>
  );
}
