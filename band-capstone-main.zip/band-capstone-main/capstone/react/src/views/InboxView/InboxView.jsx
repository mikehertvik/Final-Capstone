import { useContext, useState, useEffect } from "react";
import { Link } from 'react-router-dom';
import { UserContext } from '../../context/UserContext';
import NotificationService from "../../services/NotificationService";
import Message from "../../components/Message/Message";
import Notification from "../../components/Notification/Notification";
import styles from './InboxView.module.css';


export default function InboxView() {
    const user = useContext(UserContext);
    const [isLoading, setIsLoading] = useState(true);
    const [notifications, setNotifications] = useState([]);
    const [selectedNotification, setSelectedNotification] = useState();

    useEffect(() => {
        user && NotificationService.getAllNotifications()
            .then((response) => {
                setNotifications(response.data);
                setIsLoading(false);
            })
            .catch((error) => {
                console.error("Error loading notifications: ", error);
                setIsLoading(false);
            });
    }, [user]);

    function handleSelect(notification) {
        setSelectedNotification(notification);
        console.log(selectedNotification);
    }


    return(
        <div className={styles.inboxView}>
        <section id="Inbox-Menu">
        </section>
        <section  id="Notification-Selection" className={styles.container}>
            <div className={styles.notificationsContainer}>
                <ul className={styles.notifications}>
                    {notifications.length > 0 ? (
                        notifications.map ((notification) => (
                            <li key={notification.notifId} onClick={() => handleSelect(notification)}>
                                <Notification className={styles.notifications} notification={notification}/>
                            </li>
                        ))
                    ):(
                        <p>No Notifications</p>
                    )}
                </ul>
            </div>
            <div className={styles.messageContainer}>
                <ul className={styles.messages}>
                     <Message selectedNotification={selectedNotification}/>
                </ul>
            </div>
        </section>
        </div>

    )
}