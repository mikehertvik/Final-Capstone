import { useContext, useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { UserContext } from '../../context/UserContext';
import BandService from '../../services/BandService';
import styles from './BandSearch.module.css';
import SearchBandCard from '../../components/SearchBandCard/SearchBandCard';
import GenreService from '../../services/GenreService';

export default function BandSearchView() {
  const [bands, setBands] = useState([]);
  const user = useContext(UserContext);
  const [isLoading, setIsLoading] = useState(true);
  const [bandName, setBandName] = useState("");
  const [selectedGenres, setSelectedGenres] = useState([]);
  const [allGenres, setAllGenres] = useState([]);
  const [followedFilter, setFollowedFilter] = useState(false);

  function getSearchData(e) {
    e.preventDefault();
    const formData = new FormData(e.target);
    const searchName = formData.get("search");
    setIsLoading(true);
    setBandName(searchName);
    BandService.getBandsByName(searchName, user.id) //put bandName instead?
      .then((response) => {
        let filteredBands = response.data;
        if(selectedGenres.length > 0) {
          filteredBands = filteredBands.filter(band => 
            band.genres.some(genre => selectedGenres.includes(genre))
          );
        }
        if (followedFilter) {
          filteredBands = filteredBands.filter(band => band.userFollowing);
        }

        setBands(filteredBands);
        setIsLoading(false);
        setSelectedGenres([]);
      })
      .catch((error) => {
        const errorMessage = error.response ? error.response.data.message : error.message;
        console.error(errorMessage);
        setIsLoading(false);
      });
  }

  function handleGenreChange (e) {
    let genre = e.target.value;
      setSelectedGenres(pickedGenres => 
        pickedGenres.includes(genre) 
          ? pickedGenres.filter(g => g !== genre) 
          : [...pickedGenres, genre]
      );
  }

  function handleFollowedFilterChange() {
    setFollowedFilter(prev => !prev);
  }

  useEffect(() => {
    user && BandService.getAllBands()
      .then((response) => {
        setBands(response.data);
      })
      .catch((error) => {
        console.error("Error loading bands:", error);
        setIsLoading(false);
      });
      user && GenreService.getAllGenres()
      .then((response) => {
        setAllGenres(response.data);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error("Error loading bands:", error);
        setIsLoading(false);
      });
      console.log(allGenres);
  }, [user]);


  return (
    <>{isLoading ? (
      <p className="">Loading...</p>
    ) : (
      <div className={styles.container}>

      <h1 className={styles.header}>Search for Bands</h1> 
      <form className={styles.filter} onSubmit={getSearchData}>
        <h2>Filter By:</h2>
        <section className={styles.filterGenre}>
          <h3>Genre</h3>
           {allGenres.map(genre => (
            <div className={styles.genres} key={genre.name}>
              <label htmlFor={genre.name}>{genre.name}</label>
              <input 
                type="checkbox" 
                id={genre.id}
                checked={selectedGenres.includes(genre.name)}
                onChange={handleGenreChange}
                value={genre.name}
              />
            </div>
          ))}
        <div className={styles.followFilter}>
        <label>Followed Bands</label>
          <input
            type="checkbox"
            checked={followedFilter}
            onChange={handleFollowedFilterChange}
          />
        </div>

        </section>
        <section className={styles.filterName}>
          <label  htmlFor="search">Search by Name</label>
          <input type="text" name="search" id="search"></input>
        </section>
        <button className={styles.searchButton}type="submit">Search</button>
      </form>

      <ul className={styles.searchResults}>
      {bands.length > 0 ? (
        bands.map ((band) => (
          <li className={styles.bandCard} key={band.bandId} >{/* follow/unfollow button */}
          {/* <button className={styles.followButton} key={band.bandId} value={band.bandId} onClick= {handleFollow}>{band.userFollowing ? "-" : "+"}</button> */}
          <SearchBandCard band={band}/>
          </li>
        ))) : (
          <p className={styles.noResults}>No bands found matching your criteria</p>
        )}
      </ul>

    
      </div>
    )}
    </>
  );
}