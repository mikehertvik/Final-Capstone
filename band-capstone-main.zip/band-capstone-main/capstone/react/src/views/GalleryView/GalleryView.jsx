import { useEffect, useState, useContext, createContext } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import NotificationService from '../../services/NotificationService';
import { UserContext } from '../../context/UserContext';
import axios from 'axios';
import BandService from '../../services/BandService';
import GalleryService from '../../services/GalleryService';
import styles from './GalleryView.module.css';

export default function SendMessage() {
    const user = useContext(UserContext);
    const { bandId } = useParams();
    const [url, setUrl] = useState('');
    const navigate = useNavigate();
    const [band, setBand] = useState();
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        user && BandService.getBandById(bandId)
          .then(response => {
            setBand(response.data);
            setIsLoading(false);
          })
          .catch(error => {
            console.error(error);
            setIsLoading(false);
          });
      }, [user, bandId]);

function handleSubmit(event){
    event.preventDefault();

    const gallery = {
        imgUrl: url,
        // bandId: bandId,
    };
  
    user && GalleryService.addToGallery(bandId, gallery)
    .then(response =>{
        console.log('Message Sent!', response.data);
        navigate(`/bands/${bandId}`); // Redirect to bandpage after successful creation
    })
    .catch(error => {
        console.error('Error Sending Message', error);
        // setErrorMessage('Failed to send message. Please try again.');
    });

}
   

    return (
<>
{ !isLoading ? (band?.creator === user?.id ? (
<div className={styles.container}>
    <h1>Submit the url for your image</h1>
        <form className={styles.form} onSubmit={handleSubmit}>
            {/* <textarea id = "textbox" name="textarea" /> */}
                <div>
                    <label>Image Url:</label>
                    <input type="text" value={url} onChange={(e) => setUrl(e.target.value)} required/>
                </div>
            <button type="submit">Submit</button>
        </form>
</div>
        ) : (
     <>
     <div className={styles.backToHome}>
     <p>Unable to load page</p>
     <button className={styles.backButton} onClick={() => navigate('/')}>Back to Home</button>
     </div>
     </>
   )) : (
    <div className={styles.loading}>Loading...</div>
   )} 
</>
    );
}
