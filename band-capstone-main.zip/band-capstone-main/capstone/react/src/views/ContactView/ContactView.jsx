import styles from './ContactView.module.css';


export default function ContactView(){




    return (
<div className={styles.contactContainer}>

<ul className={styles.contactProfiles}>

<li className={styles.person}> <a href="https://www.linkedin.com/in/dave-mckenzie-columbus-ohio/">  <img src='https://media.licdn.com/dms/image/v2/D5603AQFQ72yfNP-3yg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1722537781785?e=1751500800&v=beta&t=8IIY_ABFo258Rl1aCzok6-9mOMNXVMabiCCp9mH21xw' /> Dave Mckenzie </a></li>
<li className={styles.person}> <a href="https://www.linkedin.com/in/kovackm96/">  <img src='https://media.licdn.com/dms/image/v2/D5603AQH0gBtvfjYN8Q/profile-displayphoto-shrink_200_200/B56ZUZ.EuiHEAk-/0/1739897457907?e=1751500800&v=beta&t=N7K8MTROR0GKdXLe14CuOY7aZtSnewX6crAdn8G4Lw4' /> Michael Kovack </a></li>
<li className={styles.person}> <a href="https://www.linkedin.com/in/michael-hertvik/">  <img src='https://media.licdn.com/dms/image/v2/D4E03AQGH2m3jQmFItg/profile-displayphoto-shrink_800_800/B4EZUbZKi5G0Ag-/0/1739921336810?e=1751500800&v=beta&t=qG6bT7Wja4Y6_iiFCz-NcZxDg56zMT-yFylShK3ThEE' /> Mike Hertvik </a></li>
<li className={styles.person}> <a href="https://www.linkedin.com/in/skyeahall/">  <img src='https://media.licdn.com/dms/image/v2/D4E03AQEPPuRXAjjueQ/profile-displayphoto-shrink_200_200/B4EZTI0VbyGgAY-/0/1738535951910?e=1751500800&v=beta&t=GJgNATp6kX1CEeH_zKNk6jko9RKAeIQY1KY8fss3qXU' /> Skye Hall </a></li>

</ul>

</div>
    );
}