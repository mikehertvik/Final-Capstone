
import styles from './Events.module.css'
import EventService from '../../services/EventService';
import { UserContext } from '../../context/UserContext';
import { useEffect, useState, useContext } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';


export default function Events(){
    const [events, setEvents] = useState([]);   
    const user = useContext(UserContext);
    const { bandId } = useParams();
    const [error, setError] = useState('');
    const navigate = useNavigate();

    useEffect(() => {

        user && EventService.getEventsByBand(bandId)
        .then(response => {
            setEvents(response.data);
        }).catch(error => {
                console.error(error);
                setError('Band not found.');
              });
      }, [user, bandId]);


      function handleEdit(evt){
        evt.preventDefault();
        let eventId = evt.target.value;
        navigate(`/bands/${bandId}/events/${eventId}/edit`);
      }

      function handleDelete(evt){
        evt.preventDefault();
        let eventId = evt.target.value;
        EventService.deleteEvent(bandId, eventId);
        window.location.reload();
      }

return(
  
<ul className={styles.allEvents}>
    {events && events.map((event) => (
        <div>
        <ul className={styles.singleEvent} key={event.eventId}>
    <li className={styles.name}>Title: {event.eventName} </li>    
    <li className={styles.venue}>Venue: {event.eventVenue} </li>
    <li className={styles.address}>Address: {event.eventAddress}</li>
    <li className={styles.dateTime}>Date & Time: {event.eventDateTime}</li>
    {/* <li className={styles.time}>Time: </li> */}
    </ul>
    <button className={styles.editButton} value={event.eventId} onClick={(evt) => handleEdit(evt, bandId)}>Edit</button>
    <button className={styles.removeButton} value={event.eventId} onClick={(evt) => handleDelete(evt, bandId)}>Remove</button>
    </div>
     ))} 
</ul>

)

}