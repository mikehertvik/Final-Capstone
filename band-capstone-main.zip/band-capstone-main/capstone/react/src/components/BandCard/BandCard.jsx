import { Link } from 'react-router-dom';
import styles from '../BandCard/BandCard.module.css';

export default function BandCard({ band }) {
  return (
    <article className={styles.card}>
      <img
        className={styles.img}
        src={band.profileImg}
        alt={`${band.name} profile`}
      />
      <section className={styles.content}>
        <h2 className={styles.title}>
          <Link to={`/bands/${band.bandId}`} className={styles.genreBadge}>
            {band.name}
          </Link>
        </h2>
      </section>
    </article>
  );
}