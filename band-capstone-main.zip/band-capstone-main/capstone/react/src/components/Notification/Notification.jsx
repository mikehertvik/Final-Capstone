import styles from './Notification.module.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {useState} from "react";


export default function Notification({ notification, clearNotification }) {

  let date = notification.dateSent.slice(0,10);
  let time = notification.dateSent.slice(11, 16);
    if (!notification) {
      return null;
    }
  
    return (
      <div className={styles.notifications}>
        <div role="alert" className={`${styles.content} ${styles[notification.type]}`}>
        <ul className={styles.notif}>
          <li className={styles.bandName}>{notification.bandName}</li>
          <li className={styles.subject}>{notification.notifSubject}</li>
          <li className={styles.date} >{date}</li>
          <li className={styles.time} >{time}</li>
        </ul>
          <button className={styles.button} onClick={clearNotification}>
          <FontAwesomeIcon icon="fa-solid fa-xmark" title="Close" />
          </button>
        </div>
      </div>
    );
  }
  