import {Link} from 'react-router-dom';
import styles from './SearchBandCard.module.css';
import { useEffect, useState} from 'react';
import FollowService from '../../services/FollowService';

export default function SearchBandCard({band}) {
  const [followStatus, setFollowStatus] = useState(false);

  useEffect(() => {
    FollowService.isFollowing(band.bandId)
    .then(response => {setFollowStatus(response.data);})
    .catch((error) => {
      const errorMessage = error.response ? error.response.data.message : error.message;
      console.error(errorMessage);
    });
      
  }, [])

  

  function handleFollow() {
    let bandId = band.bandId;
    if (followStatus) { 
      // unfollow band
      FollowService.unfollowBand(bandId)
      .then((response) => {
        setFollowStatus(response.data);
      })
      .catch((error) => {
        const message = error.response?.data?.message || error.message;
        console.error(`Error unfollowing band: ${message}`);
        setNotification({ type: 'error', message: 'Failed to unfollow.' });
      });
    } else {
      // follow band
      FollowService.followBand(bandId)
      .then((response) => {
        setFollowStatus(response.data);
      })
      .catch((error) => {
        const message = error.response?.data?.message || error.message;
        console.error(`Error following band: ${message}`);
      //  setNotification({ type: 'error', message: 'Failed to follow.' });
      });
      
    }
  }
  

    return (
      <article className={styles.bandCard}>
        <div className={styles.imgContainer}>
          <img
          className={styles.profileImg}
            src={band.profileImg}
          />

          {/* Follow/unfollow band button */}
          <button className={styles.followButton} onClick= {handleFollow}>{followStatus ? "-" : "+"}</button>
          

        </div>
        <section className={styles.bandDetails}>
          <h2 className={styles.bandNameContainer}>
            <Link to={`/bands/${band.bandId}`} className={styles.bandName}>
               {band.name}
            </Link>
          </h2>
        {/* <section className={styles.genre}>
          <p id={band.genre}>{band.genre}</p>
        </section> */}
        <div className={styles.genres}>
        {band.genres && band.genres.map((genre, index) => (
                    <span key={index} className={styles.genreBadge}>
                        {genre}
                    </span>
                ))}
        </div>
        </section>
      </article>
    );
  }