import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

import styles from './Message.module.css';

export default function Notification({ selectedNotification, clearNotification }) {
  if (!selectedNotification) {
    return null;
  }

  let date = selectedNotification.dateSent.slice(0,10);
  let time = selectedNotification.dateSent.slice(11, 16);

  return (
    <div className={styles.notifications}>
      <div role="alert" className={`${styles.alert} ${styles[selectedNotification.type]}`}>
       <div>
        <ul className={styles.notif}>
          <li className={styles.bandName}>{selectedNotification.bandName}</li>
          <li className={styles.date} >{date}</li>
          <li className={styles.time} >{time}</li>
        </ul>
        <li className={styles.subject}>{selectedNotification.notifSubject}</li>
        <span className={styles.message}>{selectedNotification.notifMessage}</span>
        </div>
      </div>
    </div>
  );
}
