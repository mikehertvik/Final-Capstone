import { Link, NavLink } from 'react-router-dom';
import { useContext } from 'react';
import { UserContext } from '../../context/UserContext';
import soundbridgelogo from '../../assets/soundbridgelogo.png';
import styles from './MainNav.module.css';
import App from '../../App';
import logo from '../../assets/logo.png';

export default function MainNav() {
  const user = useContext(UserContext);

  return (
    <>
    <nav id="main-nav" className={styles.navList}>
      {user ? (
        <>
      <section className={styles.navBar}>
        <img
        className={styles.logo}
        src={logo}
        alt="soundbridgelogo"
      />
      <nav className={styles.navHeader}>
        <ul className={styles.navButtons}>
          
          <li><Link className={styles.navLink} to="/bands/create">Create Band</Link></li> 

          <li><Link className={styles.navLink} to="/">Home</Link></li> 
          <li><Link className={styles.navLink} to="/bands">Search</Link></li> 
          <li><Link className={styles.navLink} to="/inbox">Inbox</Link></li> 
          <li className={styles.profileDropdown}> <span className={styles.profile}>Profile
            <ul className={styles.profileList}> 
              <li className={styles.dropdown}>
                <NavLink className= {styles.dropdownLinks} to="/logout">
                  Logout
                </NavLink>
              </li>
              <li className={styles.dropdown}>
                <Link  className= {styles.dropdownLinks} to={`/inbox`}>
                  Inbox
                </Link>
              </li>
            </ul>
            </span>
          </li>
        </ul>
        </nav>
      </section>
        </>
      ) : (
        // <div className="nav-link">
        //   <NavLink to="/login">
        //     Login
        //   </NavLink>
        // </div>
        <div>
          
        </div>
      )}
    </nav>
    </>
  );
}
