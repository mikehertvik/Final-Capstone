import axios from 'axios';


export default {

    getGalleryByBandId(bandId){
        return axios.get(`/bands/${bandId}/gallery`);
    },

    addToGallery(bandId, gallery){   
        return axios.post(`/bands/${bandId}/gallery`, gallery)
    }

}