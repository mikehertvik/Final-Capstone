import axios from 'axios';

export default {
    getBandById(bandId) {
        return axios.get(`/bands/${bandId}`);
    },

    getRandomBands(count = 3) {
        return axios.get(`/bands/random?count=${count}`);
    },

    getBandsByName(bandName) {
        return axios.get(`/bands?name=${encodeURIComponent(bandName)}`);
    },

    getAllBands() {
        return axios.get(`/bands`);
    },

    updateBand(bandId, bandData) {
        return axios.put(`/band/${bandId}`, bandData);
      },

      
      

    createBand(band) {
        return axios.post('/band');
    }
};

    
        //genres=${genres}`);

     // followBand(bandId, userId){
  //   return axios.put(`/band/${encodeURIComponent(name)/user.id/1}`);
  // }

  // unfollowBand(bandId, userId){
    // return axios.put(`/band/${encodeURIComponent(name)/user.id/0})}
  
    //getFollowers(bandId, userId){
      // return axios.get(`/band/${encodeURIComponent(name)})}
    
