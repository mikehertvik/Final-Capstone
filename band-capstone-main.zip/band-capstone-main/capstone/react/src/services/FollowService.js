import axios from "axios";

const FollowService = {
    isFollowing(bandId) {
        return axios.get(`/following/${bandId}`);
    },

    followBand(bandId) {
        return axios.put(`/bands/${bandId}`);
    },

    unfollowBand(bandId) {
        return axios.delete(`/following/${bandId}`);
    },
    // 🆕 NEW: Get number of followers
    getFollowerCount(bandId) {
        return axios.get(`/followers/count/${bandId}`);
    }
};

export default FollowService;
