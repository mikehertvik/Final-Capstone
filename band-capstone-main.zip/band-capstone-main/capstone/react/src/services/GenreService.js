import axios from "axios";

export default {

    getAllGenres() {
        return axios.get('/genres');
    }

}
