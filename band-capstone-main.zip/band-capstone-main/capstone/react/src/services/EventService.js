import axios from "axios";

export default{

    getEventsByBand(bandId){
       return axios.get(`/bands/${bandId}/events`);
    },

    getEventById(eventId, bandId) {
        return axios.get(`/bands/${bandId}/events/${eventId}`);
    },

    createEvent(bandId, event){
        return axios.post(`/bands/${bandId}/events/create`, event);
    },

    updateEvent(bandId, eventId, updatedEvent){
        return  axios.put(`/bands/${bandId}/events/${eventId}/update`, updatedEvent);
    },

    deleteEvent(bandId, eventId){
        return  axios.delete(`/bands/${bandId}/events/${eventId}/delete`);
    }
}
