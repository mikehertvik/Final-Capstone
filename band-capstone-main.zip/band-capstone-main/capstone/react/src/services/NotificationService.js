import axios from "axios";


export default {
    getAllNotifications() {
        return axios.get('/inbox');
    },


    createNotification(bandId, notification) {
        return axios.post(`/bands/${bandId}/sendMessage`, notification);
    }
    // createNotification(bandId){
    //     return axios.post(`/bands/${bandId}/sendMessage`, {
    //         subject,
    //         message,
    //         bandId: bandId || null,
    //     },
    //     {
    //         headers: {
    //             Authorization: `Bearer ${token}`
    //         }
    //     });
    // }
}