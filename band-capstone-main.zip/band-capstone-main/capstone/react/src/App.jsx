import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { UserContext } from './context/UserContext';
import AuthService from './services/AuthService';
import HomeView from './views/HomeView/HomeView';
import LoginView from './views/LoginView/LoginView';
import LogoutView from './views/LogoutView/LogoutView';
import RegisterView from './views/RegisterView/RegisterView';
import UserProfileView from './views/UserProfileView/UserProfileView';
import MainNav from './components/MainNav/MainNav';
import ProtectedRoute from './components/ProtectedRoute';
import styles from './App.module.css';
import axios from 'axios';
import BandView from './views/BandView/BandView';
import BandSearchView from './views/BandSearchView/BandSearchView';
import CreateBandView from './views/CreateBandView/CreateBandView';
import InboxView from './views/InboxView/InboxView';
import UpdateBandView from "./views/UpdateBand/UpdateBandView";
import Events from './components/Events/Events';
import SendMessageView from './views/SendMessageView/SendMessageView';
import GalleryView from './views/GalleryView/GalleryView';
import AddEvent from './views/EventView/AddEvent';
import EditEvent from './views/EventView/EditEvent';
import DeleteEvent from './views/EventView/DeleteEvent';
import ContactView from './views/ContactView/ContactView';

export default function App() {
  const [user, setUser] = useState(null);

  function handleLogin(userData) {
    setUser(userData);
  }

  function handleLogout() {
    // Remove auth data from local storage
    localStorage.removeItem('user');
    localStorage.removeItem('token');

    // Clear auth token from axios
    delete axios.defaults.headers.common['Authorization'];

    // Clear the auth context
    setUser(null);
  }

  // When a user comes back to the app or refreshes the page, check for user/token in local storage and validate it
  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = localStorage.getItem('token');

    if (user && token) {
      // Set the token in the axios default headers
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

      // Make API request to ensure token is still valid
      AuthService.getUserProfile(user.id)
        .then((response) => {
          // Token is still valid, act like user just logged in
          handleLogin(response.data);
        })
        .catch(() => {
          // Token is not valid, act lke user just logged out
          handleLogout();
        });
    }
  }, []);

  return (
    <BrowserRouter>
      <div id="app">
        <UserContext.Provider value={user}>
          <header className={styles.navHead}>
            <MainNav />
          </header>
          <main id="main-content">
            <Routes>
              <Route path="/" element={<HomeView />} />
              <Route path="/login" element={<LoginView onLogin={handleLogin} />} />
              <Route path="/logout" element={<LogoutView onLogout={handleLogout} />} />
              <Route path="/register" element={<RegisterView />} />
              <Route path="/bands/:bandId" element={<BandView />} />
              <Route path="/bands" element={<BandSearchView />} />
              <Route path="/bands/create" element={<CreateBandView />} />
              <Route path="inbox/" element={<InboxView />} />
              <Route path="/update-band/:bandId" element={<UpdateBandView />} />
              <Route path="/bands/:bandId/sendMessage" element={<SendMessageView />} />
              <Route path="/bands/:bandId/gallery" element={<GalleryView />} />
              <Route path="/bands/:bandId/events" element={<Events/>}/>
              <Route path="/bands/:bandId/events/add" element={<AddEvent/>}/>
              <Route path="/bands/:bandId/events/:eventId/edit" element={<EditEvent/>}/>
              <Route path="/bands/:bandId/events/delete" element={<DeleteEvent/>}/>
              <Route path="/contact" element={<ContactView/>}/>

              <Route
                path="/userProfile"
                element={
                  <ProtectedRoute>
                    <UserProfileView />
                  </ProtectedRoute>
                }
              />
            </Routes>
          </main>

          {user ? (
            <>
              <footer className={styles.footer}>
                <p className={styles.footerTags}> copyright </p>
                <Link to="/contact" className={styles.footerTags}>contact us</Link>
              </footer>
            </>
          ) : (
            <div></div>
          )}


        </UserContext.Provider>
      </div>
    </BrowserRouter>
  );
}
